@extends('layout.master')


@section('content')

@include('site.contact.inc.form')

<div class="main-divider  container-xxl mx-auto"></div>

 @include('site.contact.inc.info')



@endsection
